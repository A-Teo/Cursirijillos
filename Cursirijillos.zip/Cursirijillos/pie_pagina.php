	<footer>
		<p>&copy Copyrigth Cursirijillos. Todos los derechos reservados.</p>
	</footer>
</body>
</html>