<!DOCTYPE html>
<html>
<head>
	<title>Cursirijillos</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<meta name="author" content="Antonio Alurralde Sánchez" />
</head>
<body>