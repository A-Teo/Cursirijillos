samePass(){
	var p1 = document.getElementById("password").value,
	p2 = document.getElementById("repassword").value;
	return p1 == p2;
}